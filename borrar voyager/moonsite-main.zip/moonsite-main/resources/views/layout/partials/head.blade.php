		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Moonsite</title>
		
		<!-- Favicons -->
		<link type="image/x-icon" href="/assets/img/favicon.png" rel="icon">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
		<!-- Select2 CSS -->
	    <link rel="stylesheet" href="/assets/plugins/select2/css/select2.min.css">
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="/assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="/assets/plugins/fontawesome/css/all.min.css">
		
		<!-- Daterangepikcer CSS -->
		<link rel="stylesheet" href="/assets/plugins/daterangepicker/daterangepicker.css">
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="/assets/css/bootstrap-datetimepicker.min.css">
		<!-- Owl Carousel CSS -->
		<link rel="stylesheet" href="/assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="/assets/css/owl.theme.default.min.css">	

		<!-- Main CSS -->
		<link rel="stylesheet" href="/assets/css/style.css">
		@stack('styles')
  