<!DOCTYPE html>
<html>
<head>
    <title>Test Mail</title>
</head>
<body>
    <h1>{{ $data['subject'] }}</h1>
    <p>{{ $data['body'] }}</p>
</body>
</html>
